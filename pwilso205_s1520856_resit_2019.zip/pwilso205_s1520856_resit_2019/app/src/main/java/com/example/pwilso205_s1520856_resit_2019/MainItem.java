package com.example.pwilso205_s1520856_resit_2019;

/*--paul wilson, s1520856--*/

public class MainItem {
    private String chaneltitle;
    private String title;
    private String description;
    private String link;
    private String pubDate;
    private String guide;
    private String dcdate;
    private String georss;
    private String mintemp;
    private String maxtemp;
    private String winddirection;
    private String windspeed;
    private String visibility;
    private String pressure;
    private String humidity;
    private String uvrisk;
    private String pollution;
    private String sunrise;
    private String sunset;


    public MainItem(String title, String mintemp, String maxtemp, String link, String pubDate, String dcdate, String georss){
    this.chaneltitle = chaneltitle;
            this.title = title;
            this.description = description;
            this.link = link;
            this.pubDate = pubDate;
            this.guide = guide;
            this.dcdate = dcdate;
            this.georss = georss;
            this.mintemp = mintemp;
            this.maxtemp = maxtemp;
    }


    public MainItem(String maxtemp, String mintemp, String winddirection, String windspeed, String visibility, String pressure, String humidity, String uvrisk, String pollution, String sunrise, String sunset){
        this.maxtemp = maxtemp;
        this.mintemp = mintemp;
        this.winddirection = winddirection;
        this.windspeed = windspeed;
        this.visibility = visibility;
        this.pressure = pressure;
        this.humidity = humidity;
        this.uvrisk = uvrisk;
        this.pollution = pollution;
        this.sunrise = sunrise;
        this.sunset = sunset;
    }

    public String getChaneltitle() {
        return chaneltitle;
    }

    public void setChaneltitle(String chaneltitle) {
        this.chaneltitle = chaneltitle;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getPubDate() {
        return pubDate;
    }

    public void setPubDate(String pubDate) {
        this.pubDate = pubDate;
    }

    public String getPubDateString() {

        return pubDate;
    }

    public String getGuide() {
        return guide;
    }

    public void setGuide(String guide) {
        this.guide = guide;
    }

    public String getdcDate() {
        return dcdate;
    }

    public void setdcDate(String dcdate) {
        this.dcdate = getdcDate();
    }

    public String getGeoRss() {
        return georss;
    }

    public void setGeoRss(String georss) {
        this.georss = georss;
    }

    public String getMintemp() {
        return mintemp;
    }

    public void setMintemp(String mintemp) {
        this.mintemp = mintemp;
    }

    public String getMaxtemp() {
        return maxtemp;
    }

    public void setMaxtemp(String maxtemp) {
        this.maxtemp = maxtemp;
    }



}
