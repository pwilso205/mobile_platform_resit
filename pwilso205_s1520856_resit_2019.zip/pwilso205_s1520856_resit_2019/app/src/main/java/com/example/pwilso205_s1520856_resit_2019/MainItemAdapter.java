package com.example.pwilso205_s1520856_resit_2019;

/*--paul wilson, s1520856--*/

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;


public class MainItemAdapter extends ArrayAdapter<MainItem> {
    private static final String TAG = "MainItemAdapter";
    private Context mContext;
    int mResource;

    public MainItemAdapter(Context context, int resource, ArrayList<MainItem> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        String chaneltitle = getItem(position).getChaneltitle();
        String title = getItem(position).getTitle();
        String link = getItem(position).getLink();
        String description = getItem(position).getDescription();
        String pubdate = getItem(position).getPubDate();
        String dcdate = getItem(position).getdcDate();
        String georsspoint = getItem(position).getGeoRss();
        String mintemp = getItem(position).getMintemp();
        String maxtemp = getItem(position).getMaxtemp();


        MainItem mainItem = new MainItem(title, mintemp, maxtemp, link, pubdate, dcdate, georsspoint);

        LayoutInflater inflater = LayoutInflater.from(mContext);
        convertView = inflater.inflate(mResource,parent,false);

        TextView tvChanelTitle = (TextView) convertView.findViewById(R.id.mainitemview_Location);
        TextView tvTitle = (TextView) convertView.findViewById(R.id.mainitemview_title);
        TextView tvLink = (TextView) convertView.findViewById(R.id.mainitemview_link);
        //TextView tvdescription = (TextView) convertView.findViewById(R.id.mainitemview_description);
        TextView tvpubdate = (TextView) convertView.findViewById(R.id.mainitemview_pubdate);
        TextView tvdcdate = (TextView) convertView.findViewById(R.id.mainitemview_dcdate);
        TextView tvgeorss = (TextView) convertView.findViewById(R.id.mainitemview_georsspoint);
       TextView tvmintemp = (TextView) convertView.findViewById(R.id.mainitemview_mintemp);
        TextView tvmaxtemp = (TextView) convertView.findViewById(R.id.mainitemview_maxtemp);


        tvChanelTitle.setText(chaneltitle);
        tvTitle.setText(title);
        tvLink.setText(link);
        //tvdescription.setText(description);
        tvpubdate.setText(pubdate);
        tvdcdate.setText(dcdate);
        tvgeorss.setText(georsspoint);
        tvmintemp.setText(mintemp);
        tvmaxtemp.setText(maxtemp);

        return convertView;
    }
}
