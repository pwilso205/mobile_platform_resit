package com.example.pwilso205_s1520856_resit_2019;

import java.util.ArrayList;
import java.util.Date;
/*--paul wilson, s1520856--*/

public class Channel {

    private String title;
    private String link;
    private String description;
    private String language;
    private String copyright;
    private Date pubdate;
    private Date dcdate;
    private String dclanguage;
    private Image image;
    private ArrayList<MainItem> items = new ArrayList<>();

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public Date getPubdate() {
        return pubdate;
    }

    public void setPubdate(Date pubdate) {
        this.pubdate = pubdate;
    }


    public Date getDcdate() {
        return dcdate;
    }

    public void setDcdate(Date dcdate) {
        this.dcdate = dcdate;
    }

    public String getDclanguage() {
        return dclanguage;
    }

    public void setDclanguage(String dclanguage) {
        this.dclanguage = dclanguage;
    }

    public String getCopyright() {
        return copyright;
    }

    public void setCopyright(String copyright) {
        this.copyright = copyright;
    }

    public Image getImage() {
        return image;
    }

    public void setImage(Image image) {
        this.image = image;
    }

    public ArrayList<MainItem> getItems() {
        return items;
    }

    public void setItems(ArrayList<MainItem> items) {
        this.items = items;
    }

    public void addItem(MainItem item) {
        this.items.add(item);
    }

    @Override
    public String toString() {
        return "Channel{" +
                "title='" + title + '\'' +
                ", link='" + link + '\'' +
                ", description='" + description + '\'' +
                ", language='" + language + '\'' +
                ", copyright='" + copyright + '\'' +
                ", pub:date='" + pubdate + '\'' +
                ", dc:date='" + dcdate + '\'' +
                ", dc:language='" + dclanguage + '\'' +
                ", image=" + image +
                ", items=" + items +
                '}';
    }
}

