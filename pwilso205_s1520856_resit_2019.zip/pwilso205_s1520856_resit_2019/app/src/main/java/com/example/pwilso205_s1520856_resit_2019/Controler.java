package com.example.pwilso205_s1520856_resit_2019;

import java.util.ArrayList;
/*--paul wilson, s1520856--*/

public class Controler {

    private final Channel channel;

    public Controler(Channel channel) {
        this.channel = channel;
    }

    public ArrayList<MainItem> items() {
        return channel.getItems();
    }


}
