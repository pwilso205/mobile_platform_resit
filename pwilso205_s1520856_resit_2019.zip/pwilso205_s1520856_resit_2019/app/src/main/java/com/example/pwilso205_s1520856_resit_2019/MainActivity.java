package com.example.pwilso205_s1520856_resit_2019;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
/*--paul wilson, s1520856--*/

public class MainActivity extends AppCompatActivity {

    ListView listview;

    ArrayList<String> chaneltitles;
    ArrayList<String> chanellinks;
    ArrayList<String> chanelldescriptions;
    ArrayList<String> channellanguages;
    ArrayList<String> chanelcopyrights;
    ArrayList<String> chanelpubdates;
    ArrayList<String> chaneldcdates;
    ArrayList<String> chaneldclanguages;
    ArrayList<String> chaneldcrights;



    ArrayList<String> titles;
    ArrayList<String> links;
    ArrayList<String> descriptions;
    ArrayList<String> pubdates;
    ArrayList<String> dcdates;
    ArrayList<String> georsspoint;
    ArrayList<String> maxtemps;
    ArrayList<String> mintemps;
    ArrayList<String> winddirections;
    ArrayList<String> windspeeds;
    ArrayList<String> visibilities;
    ArrayList<String> pressures;
    ArrayList<String> humiditys;
    ArrayList<String> uvrisks;
    ArrayList<String> polutions;
    ArrayList<String> sunrises;
    ArrayList<String> sunsets;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listview = (ListView) findViewById(R.id.itemlistview);

        chaneltitles = new ArrayList<String>();
        chanellinks = new ArrayList<String>();
        chanelldescriptions = new ArrayList<String>();
        channellanguages = new ArrayList<String>();
        chanelcopyrights = new ArrayList<String>();
        chanelpubdates= new ArrayList<String>();
        chaneldcdates = new ArrayList<String>();
        chaneldclanguages = new ArrayList<String>();
        chaneldcrights = new ArrayList<String>();



        titles = new ArrayList<String>();
        links = new ArrayList<String>();
        descriptions = new ArrayList<String>();
        pubdates = new ArrayList<String>();
        dcdates = new ArrayList<String>();
        georsspoint= new ArrayList<String>();
        maxtemps = new ArrayList<String>();
        mintemps = new ArrayList<String>();
        winddirections = new ArrayList<String>();
        windspeeds = new ArrayList<String>();
        visibilities = new ArrayList<String>();
        pressures= new ArrayList<String>();
        humiditys = new ArrayList<String>();
        uvrisks = new ArrayList<String>();
        polutions = new ArrayList<String>();
        sunrises = new ArrayList<String>();
        sunsets = new ArrayList<String>();


        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Uri uri = Uri.parse(links.get(position));
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);

            }
        });



        new ProcessInBackground().execute();





    }


    public InputStream getInputStream(URL url)
    {
        try
        {

            return url.openConnection().getInputStream();
        }
        catch (IOException e)
        {
            return null;
        }
    }

    public class ProcessInBackground extends AsyncTask<Integer, Void, Exception>
    {
        ProgressDialog progressDialog = new ProgressDialog(MainActivity.this);

        Exception exception = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog.setMessage("loading rss feed..");
            progressDialog.show();


        }

        @Override
        protected Exception doInBackground(Integer... params) {

            try
            {
                URL url = new URL("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/2643123");



                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();


                factory.setNamespaceAware(false);


                XmlPullParser xpp = factory.newPullParser();
                XmlPullParser xpp1 = factory.newPullParser();


                xpp.setInput(getInputStream(url), "UTF_8");




                boolean insidechanel = false;
                boolean insideItem = false;



                int eventType = xpp.getEventType(); //loop control variable

                while (eventType != XmlPullParser.END_DOCUMENT)
                {

                    if (eventType == XmlPullParser.START_TAG)
                    {






                        /*--
                        else if (xpp.getName().equalsIgnoreCase("link"))
                        {
                            if (insidechanel)
                            {
                                // extract the text between <link> and </link>
                                chanellinks.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("description"))
                        {
                            if (insidechanel)
                            {
                                // extract the text between <link> and </link>
                                chanelldescriptions.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("language"))
                        {
                            if (insidechanel)
                            {
                                // extract the text between <link> and </link>
                                channellanguages.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("copyright"))
                        {
                            if (insidechanel)
                            {
                                // extract the text between <link> and </link>
                                chanelcopyrights.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("pubdate"))
                        {
                            if (insidechanel)
                            {
                                // extract the text between <link> and </link>
                                chanelpubdates.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("dc:date"))
                        {
                            if (insidechanel)
                            {
                                // extract the text between <link> and </link>
                                chaneldcdates.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("dc:language"))
                        {
                            if (insidechanel)
                            {
                                // extract the text between <link> and </link>
                                chaneldclanguages.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("dc:rights"))
                        {
                            if (insidechanel)
                            {
                                // extract the text between <link> and </link>
                                chaneldcrights.add(xpp.nextText());
                            }
                        }

                        else if (eventType == XmlPullParser.END_TAG && xpp.getName().equalsIgnoreCase("channel"))
                        {
                            insidechanel = false;
                        }

--*/

                        if (xpp.getName().equalsIgnoreCase("item"))
                        {
                            insideItem = true;
                        }
                        //if the tag is called "title"
                        else if (xpp.getName().equalsIgnoreCase("title"))
                        {
                            if (insideItem)
                            {
                                // extract the text between <title> and </title>
                                String title1 = xpp.nextText();

                                String[] maintitle = title1.split(",");

                                String maintitle1 = maintitle[0];


                                titles.add(maintitle1);
                            }
                        }
                        //if the tag is called "link"
                        else if (xpp.getName().equalsIgnoreCase("link"))
                        {
                            if (insideItem)
                            {
                                // extract the text between <link> and </link>
                                links.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("description"))
                        {
                            if (insideItem)
                            {
                                // extract the text between <link> and </link>
                                //descriptions.add(xpp.nextText());
                                String descr = xpp.nextText();
                                descriptions.add(descr);







                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("pubdate"))
                        {
                            if (insideItem)
                            {
                                // extract the text between <link> and </link>
                                pubdates.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("dc:date"))
                        {
                            if (insideItem)
                            {
                                // extract the text between <link> and </link>
                                dcdates.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("georss:point"))
                        {
                            if (insideItem)
                            {
                                // extract the text between <link> and </link>
                                georsspoint.add(xpp.nextText());
                            }
                        }




                    }

                    else if (eventType == XmlPullParser.END_TAG && xpp.getName().equalsIgnoreCase("item"))
                    {
                        insideItem = false;
                    }

                    eventType = xpp.next(); //move to next element
                }

            }
            catch (MalformedURLException e)
            {
                exception = e;
            }
            catch (XmlPullParserException e)
            {
                exception = e;
            }
            catch (IOException e)
            {
                exception = e;
            }




            try
            {
                URL url1 = new URL("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/2648579");



                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();


                factory.setNamespaceAware(false);

                XmlPullParser xpp = factory.newPullParser();



                xpp.setInput(getInputStream(url1), "UTF_8");




                boolean insideItem = false;
                boolean insidechanel = false;


                int eventType = xpp.getEventType();

                while (eventType != XmlPullParser.END_DOCUMENT)
                {

                    if (eventType == XmlPullParser.START_TAG)
                    {



                        if (xpp.getName().equalsIgnoreCase("item"))
                        {
                            insideItem = true;
                        }

                        else if (xpp.getName().equalsIgnoreCase("title"))
                        {
                            if (insideItem)
                            {
                                String title1 = xpp.nextText();

                                String[] maintitle = title1.split(",");

                                String maintitle1 = maintitle[0];


                                titles.add(maintitle1);
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("link"))
                        {
                            if (insideItem)
                            {

                                links.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("description"))
                        {
                            if (insideItem)
                            {

                                String descr = xpp.nextText();

                                descriptions.add(descr);

                                String[] descriptionItems = descr.split(",");

                                String maxtemp = descriptionItems[0];

                                maxtemps.add(maxtemp);

                                String mintemp = descriptionItems[1];

                                mintemps.add(mintemp);








                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("pubdate"))
                        {
                            if (insideItem)
                            {

                                pubdates.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("dc:date"))
                        {
                            if (insideItem)
                            {

                                dcdates.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("georss:point"))
                        {
                            if (insideItem)
                            {

                                georsspoint.add(xpp.nextText());
                            }
                        }




                    }

                    else if (eventType == XmlPullParser.END_TAG && xpp.getName().equalsIgnoreCase("item"))
                    {
                        insideItem = false;
                    }

                    eventType = xpp.next();
                }

            }
            catch (MalformedURLException e)
            {
                exception = e;
            }
            catch (XmlPullParserException e)
            {
                exception = e;
            }
            catch (IOException e)
            {
                exception = e;
            }

            try
            {
                URL url2 = new URL("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/2643743");



                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();


                factory.setNamespaceAware(false);


                XmlPullParser xpp = factory.newPullParser();



                xpp.setInput(getInputStream(url2), "UTF_8");




                boolean insideItem = false;
                boolean insidechanel = false;


                int eventType = xpp.getEventType();

                while (eventType != XmlPullParser.END_DOCUMENT)
                {

                    if (eventType == XmlPullParser.START_TAG)
                    {




                         if (xpp.getName().equalsIgnoreCase("item"))
                        {
                            insideItem = true;
                        }

                        else if (xpp.getName().equalsIgnoreCase("title"))
                        {
                            if (insideItem)
                            {
                                String title1 = xpp.nextText();

                                String[] maintitle = title1.split(",");

                                String maintitle1 = maintitle[0];


                                titles.add(maintitle1);
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("link"))
                        {
                            if (insideItem)
                            {

                                links.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("description"))
                        {
                            if (insideItem)
                            {

                                String descr = xpp.nextText();

                                descriptions.add(descr);

                                String[] descriptionItems = descr.split(",");

                                String maxtemp = descriptionItems[0];

                                maxtemps.add(maxtemp);

                                String mintemp = descriptionItems[1];

                                mintemps.add(mintemp);








                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("pubdate"))
                        {
                            if (insideItem)
                            {

                                pubdates.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("dc:date"))
                        {
                            if (insideItem)
                            {

                                dcdates.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("georss:point"))
                        {
                            if (insideItem)
                            {

                                georsspoint.add(xpp.nextText());
                            }
                        }




                    }

                    else if (eventType == XmlPullParser.END_TAG && xpp.getName().equalsIgnoreCase("item"))
                    {
                        insideItem = false;
                    }

                    eventType = xpp.next();
                }

            }
            catch (MalformedURLException e)
            {
                exception = e;
            }
            catch (XmlPullParserException e)
            {
                exception = e;
            }
            catch (IOException e)
            {
                exception = e;
            }


            try
            {
                URL url3 = new URL("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/287286");



                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();


                factory.setNamespaceAware(false);


                XmlPullParser xpp = factory.newPullParser();



                xpp.setInput(getInputStream(url3), "UTF_8");




                boolean insideItem = false;
                boolean insidechanel = false;
                // Returns the type of current event: START_TAG, END_TAG, START_DOCUMENT, END_DOCUMENT etc..
                int eventType = xpp.getEventType(); //loop control variable

                while (eventType != XmlPullParser.END_DOCUMENT)
                {
                    //if we are at a START_TAG (opening tag)
                    if (eventType == XmlPullParser.START_TAG)
                    {


                        //if the tag is called "item"
                         if (xpp.getName().equalsIgnoreCase("item"))
                        {
                            insideItem = true;
                        }
                        //if the tag is called "title"
                        else if (xpp.getName().equalsIgnoreCase("title"))
                        {
                            if (insideItem)
                            {
                                String title1 = xpp.nextText();

                                String[] maintitle = title1.split(",");

                                String maintitle1 = maintitle[0];


                                titles.add(maintitle1);
                            }
                        }
                        //if the tag is called "link"
                        else if (xpp.getName().equalsIgnoreCase("link"))
                        {
                            if (insideItem)
                            {
                                // extract the text between <link> and </link>
                                links.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("description"))
                        {
                            if (insideItem)
                            {
                                // extract the text between <link> and </link>
                                //descriptions.add(xpp.nextText());
                                String descr = xpp.nextText();

                                descriptions.add(descr);

                                String[] descriptionItems = descr.split(",");

                                String maxtemp = descriptionItems[0];

                                maxtemps.add(maxtemp);

                                String mintemp = descriptionItems[1];

                                mintemps.add(mintemp);








                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("pubdate"))
                        {
                            if (insideItem)
                            {
                                // extract the text between <link> and </link>
                                pubdates.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("dc:date"))
                        {
                            if (insideItem)
                            {
                                // extract the text between <link> and </link>
                                dcdates.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("georss:point"))
                        {
                            if (insideItem)
                            {
                                // extract the text between <link> and </link>
                                georsspoint.add(xpp.nextText());
                            }
                        }




                    }
                    //if we are at an END_TAG and the END_TAG is called "item"
                    else if (eventType == XmlPullParser.END_TAG && xpp.getName().equalsIgnoreCase("item"))
                    {
                        insideItem = false;
                    }

                    eventType = xpp.next(); //move to next element
                }

            }
            catch (MalformedURLException e)
            {
                exception = e;
            }
            catch (XmlPullParserException e)
            {
                exception = e;
            }
            catch (IOException e)
            {
                exception = e;
            }


            try
            {
                URL url4 = new URL("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/934154");



                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();


                factory.setNamespaceAware(false);


                XmlPullParser xpp = factory.newPullParser();



                xpp.setInput(getInputStream(url4), "UTF_8");




                boolean insideItem = false;
                boolean insidechanel = false;

                int eventType = xpp.getEventType();

                while (eventType != XmlPullParser.END_DOCUMENT)
                {

                    if (eventType == XmlPullParser.START_TAG)
                    {


                         if (xpp.getName().equalsIgnoreCase("item"))
                        {
                            insideItem = true;
                        }

                        else if (xpp.getName().equalsIgnoreCase("title"))
                        {
                            if (insideItem)
                            {
                                String title1 = xpp.nextText();

                                String[] maintitle = title1.split(",");

                                String maintitle1 = maintitle[0];


                                titles.add(maintitle1);
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("link"))
                        {
                            if (insideItem)
                            {

                                links.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("description"))
                        {
                            if (insideItem)
                            {

                                String descr = xpp.nextText();

                                descriptions.add(descr);

                                String[] descriptionItems = descr.split(",");

                                String maxtemp = descriptionItems[0];

                                maxtemps.add(maxtemp);

                                String mintemp = descriptionItems[1];

                                mintemps.add(mintemp);








                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("pubdate"))
                        {
                            if (insideItem)
                            {

                                pubdates.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("dc:date"))
                        {
                            if (insideItem)
                            {

                                dcdates.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("georss:point"))
                        {
                            if (insideItem)
                            {

                                georsspoint.add(xpp.nextText());
                            }
                        }




                    }

                    else if (eventType == XmlPullParser.END_TAG && xpp.getName().equalsIgnoreCase("item"))
                    {
                        insideItem = false;
                    }

                    eventType = xpp.next();
                }

            }
            catch (MalformedURLException e)
            {
                exception = e;
            }
            catch (XmlPullParserException e)
            {
                exception = e;
            }
            catch (IOException e)
            {
                exception = e;
            }

            try
            {
                URL url5 = new URL("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/5128581");



                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();


                factory.setNamespaceAware(false);


                XmlPullParser xpp = factory.newPullParser();



                xpp.setInput(getInputStream(url5), "UTF_8");




                boolean insideItem = false;
                boolean insidechanel= false;

                int eventType = xpp.getEventType(); //loop control variable

                while (eventType != XmlPullParser.END_DOCUMENT)
                {

                    if (eventType == XmlPullParser.START_TAG)
                    {


                         if (xpp.getName().equalsIgnoreCase("item"))
                        {
                            insideItem = true;
                        }

                        else if (xpp.getName().equalsIgnoreCase("title"))
                        {
                            if (insideItem)
                            {
                                String title1 = xpp.nextText();

                                String[] maintitle = title1.split(",");

                                String maintitle1 = maintitle[0];


                                titles.add(maintitle1);
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("link"))
                        {
                            if (insideItem)
                            {

                                links.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("description"))
                        {
                            if (insideItem)
                            {

                                String descr = xpp.nextText();

                                descriptions.add(descr);

                                String[] descriptionItems = descr.split(",");

                                String maxtemp = descriptionItems[0];

                                maxtemps.add(maxtemp);

                                String mintemp = descriptionItems[1];

                                mintemps.add(mintemp);








                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("pubdate"))
                        {
                            if (insideItem)
                            {

                                pubdates.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("dc:date"))
                        {
                            if (insideItem)
                            {

                                dcdates.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("georss:point"))
                        {
                            if (insideItem)
                            {

                                georsspoint.add(xpp.nextText());
                            }
                        }




                    }

                    else if (eventType == XmlPullParser.END_TAG && xpp.getName().equalsIgnoreCase("item"))
                    {
                        insideItem = false;
                    }

                    eventType = xpp.next();
                }

            }
            catch (MalformedURLException e)
            {
                exception = e;
            }
            catch (XmlPullParserException e)
            {
                exception = e;
            }
            catch (IOException e)
            {
                exception = e;
            }



            try
            {
                URL url6 = new URL("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/1185241");



                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();


                factory.setNamespaceAware(false);


                XmlPullParser xpp = factory.newPullParser();



                xpp.setInput(getInputStream(url6), "UTF_8");




                boolean insideItem = false;


                int eventType = xpp.getEventType();

                while (eventType != XmlPullParser.END_DOCUMENT)
                {

                    if (eventType == XmlPullParser.START_TAG)
                    {

                        if (xpp.getName().equalsIgnoreCase("item"))
                        {
                            insideItem = true;
                        }

                        else if (xpp.getName().equalsIgnoreCase("title"))
                        {
                            if (insideItem)
                            {
                                String title1 = xpp.nextText();

                                String[] maintitle = title1.split(",");

                                String maintitle1 = maintitle[0];


                                titles.add(maintitle1);
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("link"))
                        {
                            if (insideItem)
                            {

                                links.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("description"))
                        {
                            if (insideItem)
                            {

                                String descr = xpp.nextText();

                                descriptions.add(descr);

                                String[] descriptionItems = descr.split(",");

                                String maxtemp = descriptionItems[0];

                                maxtemps.add(maxtemp);

                                String mintemp = descriptionItems[1];

                                mintemps.add(mintemp);








                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("pubdate"))
                        {
                            if (insideItem)
                            {

                                pubdates.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("dc:date"))
                        {
                            if (insideItem)
                            {

                                dcdates.add(xpp.nextText());
                            }
                        }

                        else if (xpp.getName().equalsIgnoreCase("georss:point"))
                        {
                            if (insideItem)
                            {

                                georsspoint.add(xpp.nextText());
                            }
                        }




                    }
                    //if we are at an END_TAG and the END_TAG is called "item"
                    else if (eventType == XmlPullParser.END_TAG && xpp.getName().equalsIgnoreCase("item"))
                    {
                        insideItem = false;
                    }

                    eventType = xpp.next(); //move to next element
                }

            }
            catch (MalformedURLException e)
            {
                exception = e;
            }
            catch (XmlPullParserException e)
            {
                exception = e;
            }
            catch (IOException e)
            {
                exception = e;
            }






            return exception;








        }

        ////////////////////////////////////////////////////////////////////////////////////






        protected void onPostExecute(Exception s) {
            super.onPostExecute(s);

            ListView mListView = (ListView) findViewById(R.id.itemlistview);


            MainItem mainitem1 = new MainItem(titles.get(0),mintemps.get(0), maxtemps.get(0), links.get(0), pubdates.get(0), dcdates.get(0), georsspoint.get(0));
            MainItem mainitem2 = new MainItem(titles.get(1), mintemps.get(1), maxtemps.get(1), links.get(1), pubdates.get(1), dcdates.get(1), georsspoint.get(1));
            MainItem mainitem3 = new MainItem(titles.get(2), mintemps.get(2), maxtemps.get(2), links.get(2), pubdates.get(2), dcdates.get(2), georsspoint.get(2));

            MainItem mainitem4 = new MainItem(titles.get(3), mintemps.get(3), maxtemps.get(3),links.get(3), pubdates.get(3), dcdates.get(3), georsspoint.get(3));
            MainItem mainitem5 = new MainItem(titles.get(4), mintemps.get(4), maxtemps.get(4), links.get(4), pubdates.get(4), dcdates.get(4), georsspoint.get(4));
            MainItem mainitem6 = new MainItem(titles.get(5), mintemps.get(5), maxtemps.get(5), links.get(5), pubdates.get(5), dcdates.get(5), georsspoint.get(5));

            MainItem mainitem7 = new MainItem(titles.get(6),mintemps.get(6), maxtemps.get(6), links.get(6), pubdates.get(6), dcdates.get(6), georsspoint.get(6));
            MainItem mainitem8 = new MainItem(titles.get(7), mintemps.get(7), maxtemps.get(7), links.get(7), pubdates.get(7), dcdates.get(7), georsspoint.get(7));
            MainItem mainitem9 = new MainItem(titles.get(8), mintemps.get(8), maxtemps.get(8), links.get(8), pubdates.get(8), dcdates.get(8), georsspoint.get(8));

            MainItem mainitem10 = new MainItem(titles.get(9), mintemps.get(9), maxtemps.get(9),links.get(9), pubdates.get(9), dcdates.get(9), georsspoint.get(9));
            MainItem mainitem11 = new MainItem(titles.get(10), mintemps.get(10), maxtemps.get(10), links.get(10), pubdates.get(10), dcdates.get(10), georsspoint.get(10));
            MainItem mainitem12 = new MainItem(titles.get(11), mintemps.get(11), maxtemps.get(11), links.get(11), pubdates.get(11), dcdates.get(11), georsspoint.get(11));

            MainItem mainitem13 = new MainItem(titles.get(12), mintemps.get(12), maxtemps.get(12),links.get(12), pubdates.get(12), dcdates.get(12), georsspoint.get(12));
            MainItem mainitem14 = new MainItem(titles.get(13), mintemps.get(13), maxtemps.get(13), links.get(13), pubdates.get(13), dcdates.get(13), georsspoint.get(13));
            MainItem mainitem15 = new MainItem(titles.get(14), mintemps.get(14), maxtemps.get(14), links.get(14), pubdates.get(14), dcdates.get(14), georsspoint.get(14));

            MainItem mainitem16 = new MainItem(titles.get(15), mintemps.get(15), maxtemps.get(15),links.get(15), pubdates.get(15), dcdates.get(15), georsspoint.get(15));
            MainItem mainitem17 = new MainItem(titles.get(16), mintemps.get(16), maxtemps.get(16), links.get(16), pubdates.get(16), dcdates.get(16), georsspoint.get(16));
            MainItem mainitem18 = new MainItem(titles.get(17), mintemps.get(17), maxtemps.get(17), links.get(17), pubdates.get(17), dcdates.get(17), georsspoint.get(17));




            ArrayList<MainItem> mainitemlist = new ArrayList<>();

            mainitemlist.add(mainitem1);
            mainitemlist.add(mainitem2);
            mainitemlist.add(mainitem3);
            mainitemlist.add(mainitem4);
            mainitemlist.add(mainitem5);
            mainitemlist.add(mainitem6);
            mainitemlist.add(mainitem7);
            mainitemlist.add(mainitem8);
            mainitemlist.add(mainitem9);
            mainitemlist.add(mainitem10);
            mainitemlist.add(mainitem11);
            mainitemlist.add(mainitem12);
            mainitemlist.add(mainitem13);
            mainitemlist.add(mainitem14);
            mainitemlist.add(mainitem15);
            mainitemlist.add(mainitem16);
            mainitemlist.add(mainitem17);
            mainitemlist.add(mainitem18);



            //MainItemAdapter adapter = new MainItemAdapter(this,R.layout.main_item_view,mainitemlist);
            // mListView.setAdapter(adapter);

           // ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, descriptions);


            //lvRss.setAdapter(adapter);

            //MainItemAdapter adapter = new MainItemAdapter(this,R.layout.main_item_view,mainitemlist);

            MainItemAdapter adapter = new MainItemAdapter(getApplicationContext(),R.layout.main_item_view,mainitemlist);

            mListView.setAdapter(adapter);

            progressDialog.dismiss();



        }


    }


}
